
from django.urls import path
from .views import student_list, studentByID
urlpatterns = [

    path('Students/', student_list),
    path('Students/id/<int:id>/', studentByID),
    ]
