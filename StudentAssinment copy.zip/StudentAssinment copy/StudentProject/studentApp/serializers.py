from rest_framework import serializers
from .models import StudentModel

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentModel
        fields = ['id', 'StudentName', 'StudentNumber', 'FacultyName' ]








    # StudentName = serializers.CharField(max_length=100)
    # StudentNumber = serializers.CharField(max_length=10)
    # FacultyName = serializers.CharField(max_length=100)
    #
    # def create(self, validated_data):
    #     return StudentModel.objects.create(validated_data)
    #
    # def update(self, instance, validated_data):
    #     instance.StudentName = validated_data.get('StudentName', instance.StudentName)
    #     instance.StudentNumer = validated_data.get('StudentNumber', instance.StudentNumer)
    #     instance.FacultyName = validated_data.get('Facultyname', instance.FacultyName)
    #     instance.save()
    #     return instance